<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-03 15:55:42 --> Config Class Initialized
INFO - 2025-06-03 15:55:42 --> Hooks Class Initialized
DEBUG - 2025-06-03 15:55:42 --> UTF-8 Support Enabled
INFO - 2025-06-03 15:55:42 --> Utf8 Class Initialized
INFO - 2025-06-03 15:55:42 --> URI Class Initialized
INFO - 2025-06-03 15:55:42 --> Router Class Initialized
INFO - 2025-06-03 15:55:42 --> Output Class Initialized
INFO - 2025-06-03 15:55:42 --> Security Class Initialized
DEBUG - 2025-06-03 15:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 15:55:42 --> Input Class Initialized
INFO - 2025-06-03 15:55:42 --> Language Class Initialized
INFO - 2025-06-03 15:55:42 --> Loader Class Initialized
INFO - 2025-06-03 15:55:42 --> Helper loaded: url_helper
INFO - 2025-06-03 15:55:42 --> Database Driver Class Initialized
DEBUG - 2025-06-03 15:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 15:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 15:55:42 --> Controller Class Initialized
INFO - 2025-06-03 15:55:42 --> Model "User_model" initialized
INFO - 2025-06-03 15:55:42 --> Helper loaded: form_helper
INFO - 2025-06-03 15:55:42 --> Form Validation Class Initialized
INFO - 2025-06-03 15:55:42 --> File loaded: C:\laragon\www\penjualan\application\views\template/header.php
INFO - 2025-06-03 15:55:42 --> File loaded: C:\laragon\www\penjualan\application\views\template/navbar.php
INFO - 2025-06-03 15:55:42 --> File loaded: C:\laragon\www\penjualan\application\views\template/sidebar.php
INFO - 2025-06-03 15:55:42 --> File loaded: C:\laragon\www\penjualan\application\views\user/index.php
INFO - 2025-06-03 15:55:42 --> File loaded: C:\laragon\www\penjualan\application\views\template/footer.php
INFO - 2025-06-03 15:55:42 --> File loaded: C:\laragon\www\penjualan\application\views\template/main.php
INFO - 2025-06-03 15:55:42 --> Final output sent to browser
DEBUG - 2025-06-03 15:55:42 --> Total execution time: 0.1210
INFO - 2025-06-03 15:55:59 --> Config Class Initialized
INFO - 2025-06-03 15:55:59 --> Hooks Class Initialized
DEBUG - 2025-06-03 15:55:59 --> UTF-8 Support Enabled
INFO - 2025-06-03 15:55:59 --> Utf8 Class Initialized
INFO - 2025-06-03 15:55:59 --> URI Class Initialized
INFO - 2025-06-03 15:55:59 --> Router Class Initialized
INFO - 2025-06-03 15:55:59 --> Output Class Initialized
INFO - 2025-06-03 15:55:59 --> Security Class Initialized
DEBUG - 2025-06-03 15:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 15:55:59 --> Input Class Initialized
INFO - 2025-06-03 15:55:59 --> Language Class Initialized
INFO - 2025-06-03 15:55:59 --> Loader Class Initialized
INFO - 2025-06-03 15:55:59 --> Helper loaded: url_helper
INFO - 2025-06-03 15:55:59 --> Database Driver Class Initialized
DEBUG - 2025-06-03 15:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 15:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 15:55:59 --> Controller Class Initialized
INFO - 2025-06-03 15:55:59 --> Model "User_model" initialized
INFO - 2025-06-03 15:55:59 --> Helper loaded: form_helper
INFO - 2025-06-03 15:55:59 --> Form Validation Class Initialized
INFO - 2025-06-03 15:55:59 --> File loaded: C:\laragon\www\penjualan\application\views\template/header.php
INFO - 2025-06-03 15:55:59 --> File loaded: C:\laragon\www\penjualan\application\views\template/navbar.php
INFO - 2025-06-03 15:55:59 --> File loaded: C:\laragon\www\penjualan\application\views\template/sidebar.php
INFO - 2025-06-03 15:55:59 --> File loaded: C:\laragon\www\penjualan\application\views\user/add_form.php
INFO - 2025-06-03 15:55:59 --> File loaded: C:\laragon\www\penjualan\application\views\template/footer.php
INFO - 2025-06-03 15:55:59 --> File loaded: C:\laragon\www\penjualan\application\views\template/main.php
INFO - 2025-06-03 15:55:59 --> Final output sent to browser
DEBUG - 2025-06-03 15:55:59 --> Total execution time: 0.1036
INFO - 2025-06-03 15:56:14 --> Config Class Initialized
INFO - 2025-06-03 15:56:14 --> Hooks Class Initialized
DEBUG - 2025-06-03 15:56:14 --> UTF-8 Support Enabled
INFO - 2025-06-03 15:56:14 --> Utf8 Class Initialized
INFO - 2025-06-03 15:56:14 --> URI Class Initialized
INFO - 2025-06-03 15:56:14 --> Router Class Initialized
INFO - 2025-06-03 15:56:14 --> Output Class Initialized
INFO - 2025-06-03 15:56:14 --> Security Class Initialized
DEBUG - 2025-06-03 15:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 15:56:14 --> Input Class Initialized
INFO - 2025-06-03 15:56:14 --> Language Class Initialized
INFO - 2025-06-03 15:56:14 --> Loader Class Initialized
INFO - 2025-06-03 15:56:14 --> Helper loaded: url_helper
INFO - 2025-06-03 15:56:14 --> Database Driver Class Initialized
DEBUG - 2025-06-03 15:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 15:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 15:56:14 --> Controller Class Initialized
INFO - 2025-06-03 15:56:14 --> Model "User_model" initialized
INFO - 2025-06-03 15:56:14 --> Helper loaded: form_helper
INFO - 2025-06-03 15:56:14 --> Form Validation Class Initialized
INFO - 2025-06-03 15:56:14 --> Config Class Initialized
INFO - 2025-06-03 15:56:14 --> Hooks Class Initialized
DEBUG - 2025-06-03 15:56:14 --> UTF-8 Support Enabled
INFO - 2025-06-03 15:56:14 --> Utf8 Class Initialized
INFO - 2025-06-03 15:56:14 --> URI Class Initialized
INFO - 2025-06-03 15:56:14 --> Router Class Initialized
INFO - 2025-06-03 15:56:14 --> Output Class Initialized
INFO - 2025-06-03 15:56:14 --> Security Class Initialized
DEBUG - 2025-06-03 15:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 15:56:14 --> Input Class Initialized
INFO - 2025-06-03 15:56:14 --> Language Class Initialized
INFO - 2025-06-03 15:56:14 --> Loader Class Initialized
INFO - 2025-06-03 15:56:14 --> Helper loaded: url_helper
INFO - 2025-06-03 15:56:14 --> Database Driver Class Initialized
DEBUG - 2025-06-03 15:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 15:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 15:56:14 --> Controller Class Initialized
INFO - 2025-06-03 15:56:14 --> Model "User_model" initialized
INFO - 2025-06-03 15:56:14 --> Helper loaded: form_helper
INFO - 2025-06-03 15:56:14 --> Form Validation Class Initialized
INFO - 2025-06-03 15:56:14 --> File loaded: C:\laragon\www\penjualan\application\views\template/header.php
INFO - 2025-06-03 15:56:14 --> File loaded: C:\laragon\www\penjualan\application\views\template/navbar.php
INFO - 2025-06-03 15:56:14 --> File loaded: C:\laragon\www\penjualan\application\views\template/sidebar.php
INFO - 2025-06-03 15:56:14 --> File loaded: C:\laragon\www\penjualan\application\views\user/index.php
INFO - 2025-06-03 15:56:14 --> File loaded: C:\laragon\www\penjualan\application\views\template/footer.php
INFO - 2025-06-03 15:56:14 --> File loaded: C:\laragon\www\penjualan\application\views\template/main.php
INFO - 2025-06-03 15:56:14 --> Final output sent to browser
DEBUG - 2025-06-03 15:56:14 --> Total execution time: 0.1049
INFO - 2025-06-03 15:58:56 --> Config Class Initialized
INFO - 2025-06-03 15:58:56 --> Hooks Class Initialized
DEBUG - 2025-06-03 15:58:56 --> UTF-8 Support Enabled
INFO - 2025-06-03 15:58:56 --> Utf8 Class Initialized
INFO - 2025-06-03 15:58:56 --> URI Class Initialized
INFO - 2025-06-03 15:58:56 --> Router Class Initialized
INFO - 2025-06-03 15:58:56 --> Output Class Initialized
INFO - 2025-06-03 15:58:56 --> Security Class Initialized
DEBUG - 2025-06-03 15:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 15:58:56 --> Input Class Initialized
INFO - 2025-06-03 15:58:56 --> Language Class Initialized
INFO - 2025-06-03 15:58:56 --> Loader Class Initialized
INFO - 2025-06-03 15:58:56 --> Helper loaded: url_helper
INFO - 2025-06-03 15:58:56 --> Database Driver Class Initialized
DEBUG - 2025-06-03 15:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 15:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 15:58:56 --> Controller Class Initialized
INFO - 2025-06-03 15:58:56 --> Model "User_model" initialized
INFO - 2025-06-03 15:58:56 --> Helper loaded: form_helper
INFO - 2025-06-03 15:58:56 --> Form Validation Class Initialized
INFO - 2025-06-03 15:58:56 --> File loaded: C:\laragon\www\penjualan\application\views\template/header.php
INFO - 2025-06-03 15:58:56 --> File loaded: C:\laragon\www\penjualan\application\views\template/navbar.php
INFO - 2025-06-03 15:58:56 --> File loaded: C:\laragon\www\penjualan\application\views\template/sidebar.php
INFO - 2025-06-03 15:58:56 --> File loaded: C:\laragon\www\penjualan\application\views\user/edit_form.php
INFO - 2025-06-03 15:58:56 --> File loaded: C:\laragon\www\penjualan\application\views\template/footer.php
INFO - 2025-06-03 15:58:56 --> File loaded: C:\laragon\www\penjualan\application\views\template/main.php
INFO - 2025-06-03 15:58:56 --> Final output sent to browser
DEBUG - 2025-06-03 15:58:56 --> Total execution time: 0.1279
INFO - 2025-06-03 15:59:01 --> Config Class Initialized
INFO - 2025-06-03 15:59:01 --> Hooks Class Initialized
DEBUG - 2025-06-03 15:59:01 --> UTF-8 Support Enabled
INFO - 2025-06-03 15:59:01 --> Utf8 Class Initialized
INFO - 2025-06-03 15:59:01 --> URI Class Initialized
INFO - 2025-06-03 15:59:01 --> Router Class Initialized
INFO - 2025-06-03 15:59:01 --> Output Class Initialized
INFO - 2025-06-03 15:59:01 --> Security Class Initialized
DEBUG - 2025-06-03 15:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 15:59:01 --> Input Class Initialized
INFO - 2025-06-03 15:59:01 --> Language Class Initialized
INFO - 2025-06-03 15:59:01 --> Loader Class Initialized
INFO - 2025-06-03 15:59:01 --> Helper loaded: url_helper
INFO - 2025-06-03 15:59:01 --> Database Driver Class Initialized
DEBUG - 2025-06-03 15:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 15:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 15:59:01 --> Controller Class Initialized
INFO - 2025-06-03 15:59:01 --> Model "User_model" initialized
INFO - 2025-06-03 15:59:01 --> Helper loaded: form_helper
INFO - 2025-06-03 15:59:01 --> Form Validation Class Initialized
ERROR - 2025-06-03 15:59:01 --> Severity: 8192 --> password_hash(): Passing null to parameter #1 ($password) of type string is deprecated C:\laragon\www\penjualan\application\models\user_model.php 33
INFO - 2025-06-03 15:59:01 --> Config Class Initialized
INFO - 2025-06-03 15:59:01 --> Hooks Class Initialized
DEBUG - 2025-06-03 15:59:01 --> UTF-8 Support Enabled
INFO - 2025-06-03 15:59:01 --> Utf8 Class Initialized
INFO - 2025-06-03 15:59:01 --> URI Class Initialized
INFO - 2025-06-03 15:59:01 --> Router Class Initialized
INFO - 2025-06-03 15:59:01 --> Output Class Initialized
INFO - 2025-06-03 15:59:01 --> Security Class Initialized
DEBUG - 2025-06-03 15:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 15:59:01 --> Input Class Initialized
INFO - 2025-06-03 15:59:01 --> Language Class Initialized
INFO - 2025-06-03 15:59:01 --> Loader Class Initialized
INFO - 2025-06-03 15:59:01 --> Helper loaded: url_helper
INFO - 2025-06-03 15:59:01 --> Database Driver Class Initialized
DEBUG - 2025-06-03 15:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 15:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 15:59:01 --> Controller Class Initialized
INFO - 2025-06-03 15:59:01 --> Model "User_model" initialized
INFO - 2025-06-03 15:59:01 --> Helper loaded: form_helper
INFO - 2025-06-03 15:59:01 --> Form Validation Class Initialized
INFO - 2025-06-03 15:59:01 --> File loaded: C:\laragon\www\penjualan\application\views\template/header.php
INFO - 2025-06-03 15:59:01 --> File loaded: C:\laragon\www\penjualan\application\views\template/navbar.php
INFO - 2025-06-03 15:59:01 --> File loaded: C:\laragon\www\penjualan\application\views\template/sidebar.php
INFO - 2025-06-03 15:59:01 --> File loaded: C:\laragon\www\penjualan\application\views\user/index.php
INFO - 2025-06-03 15:59:01 --> File loaded: C:\laragon\www\penjualan\application\views\template/footer.php
INFO - 2025-06-03 15:59:01 --> File loaded: C:\laragon\www\penjualan\application\views\template/main.php
INFO - 2025-06-03 15:59:01 --> Final output sent to browser
DEBUG - 2025-06-03 15:59:01 --> Total execution time: 0.0927
